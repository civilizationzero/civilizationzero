Civilization Zero — preservation bundle 1.0-pre (unsigned pre-release)
Built by site/build.py in https://github.com/civilizationzero/civilizationzero; deterministic (fixed member times, sorted members, no build timestamp), so the same contents give the same hash.

This bundle is self-contained: everything needed to verify the record is in it; nothing depends on a live service.

Hashing conventions: SHA-256 over the exact file bytes. Canonical texts are UTF-8, no byte-order mark, LF line endings, nothing normalised.
  record/CZ-CORE-1.0.txt  92a8d1e2a1604c25b432685673be78184bf05c3b166893c437e0895b7b2d724a
  record/CZ-IR-1.0.txt    71e1488e631e090c0820bf8b78b1fda70ffacba1da146c36d8893600320fcc8d
  prompts/cz-machine-1.0.txt  f871380dfe1b53e74ff8c4353fc95d60faa180edca36122ca7bbe8313ba2829a

Contents: the canonical texts and their JSON forms; the objections register; the blueprint (1.3.1) as Markdown and PDF; every outside review archived so far, with the findings register; the licences; the manifest; the machine prompt; the OpenAPI contract.
The signature, the timestamp proof, the mirrors and the deposit are pending (target 2026-11-30); the signed 1.0 bundle replaces this one at launch, and this one stays at its address.
Licence: text CC BY 4.0, code MIT. Contact: record@civilizationzero.ai.
