Civilization Zero — preservation bundle 1.0.1; the canonical texts and the release manifest are signed (signatures/); this bundle's own detached signature, when published, is cz-bundle-1.0.1.tar.sig next to it
Built by site/build.py in https://github.com/civilizationzero/civilizationzero; deterministic (fixed member times, sorted members, no build timestamp), so the same contents give the same hash.

This bundle is self-contained: everything needed to verify the record is in it; nothing depends on a live service.

To verify it: python3 verify/verify.py — Python 3.8 or later, standard library only, no network. It checks the key, the
signatures, every hash, the timestamp proofs and the discussion's daily chain carried here. Its trust anchor is the key
fingerprint 82662396484f627a63272bcd5ac19aae72def7aca2898216dc8e7f975dfc2263: compare it with one obtained elsewhere (the DOI deposit, the repository, a printed copy, the
second key-holder), because a copy of the verifier can be altered together with the bundle it came with. With OpenSSL
alone: sign/verify.sh signatures/cz-record-signing.pub <file> (expects <file>.sig beside it).
The release manifest is timestamped twice, independently: an OpenTimestamps proof (signatures/cz-release-1.0.json.ots, anchored in Bitcoin block 973584) and RFC 3161 time-stamp tokens (signatures/cz-release-1.0.json.freetsa.tsr, signatures/cz-release-1.0.json.digicert.tsr; check one with: openssl ts -verify -data signatures/cz-release-1.0.json -in signatures/cz-release-1.0.json.freetsa.tsr -CAfile signatures/tsa/freetsa-cacert.pem -untrusted signatures/tsa/freetsa-tsa.crt; FreeTSA publishes the SHA-256 of those two files at https://freetsa.org/: 2151b61137ffa86bf664691ba67e7da0b19f98c758e3d228d5d8ebf27e044438 and 8bfb0305bb64e2571ca507552ef3245cb1c2fee8728e0ff8689225081ea13467, and verify.py pins them). The time a token states holds once its authority's signature verifies.

Hashing conventions: SHA-256 over the exact file bytes. Canonical texts are UTF-8, no byte-order mark, LF line endings, nothing normalised.
  record/CZ-CORE-1.0.txt  92a8d1e2a1604c25b432685673be78184bf05c3b166893c437e0895b7b2d724a
  record/CZ-IR-1.0.txt    71e1488e631e090c0820bf8b78b1fda70ffacba1da146c36d8893600320fcc8d
  prompts/cz-machine-1.0.txt  f871380dfe1b53e74ff8c4353fc95d60faa180edca36122ca7bbe8313ba2829a

Contents: the canonical texts, their JSON forms and the Core's translations (record/); the objections register; the blueprint (1.3.1) as Markdown and PDF; every outside review archived so far, with the findings register; the licences; the manifest; the machine prompt; the OpenAPI contract; the public key, the signatures, the timestamp proofs and tokens (signatures/); the signing scripts (sign/); the verifier (verify/verify.py).
Still pending: the independent mirrors. Earlier bundles stay at their addresses: cz-bundle-1.0-pre.tar, cz-bundle-1.0.tar. The repository is deposited at each release (v1.0: https://doi.org/10.5281/zenodo.23741225; v1.0-pre: https://doi.org/10.5281/zenodo.23740318) (all versions: https://doi.org/10.5281/zenodo.23740317).
The discussion room: open since 2026-10-28T18:29:12Z (bundle 1.0 gave the local date in Kuala Lumpur, 2026-10-29; the site keeps time in UTC). Its archive is served live (/discuss.json, /archive/entries/{date}.json, the chain at /archive/entries.json); no day had been hashed when this bundle was built; the daily snapshots are committed to the repository (archive/discussion/) and go into the next bundle.
Licence: text CC BY 4.0, code MIT. Contact: record@civilizationzero.ai.
